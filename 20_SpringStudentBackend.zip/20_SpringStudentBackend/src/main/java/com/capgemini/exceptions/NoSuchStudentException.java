package com.capgemini.exceptions;
// Exception Defination
public class NoSuchStudentException extends Exception{
	public NoSuchStudentException(String message) {
		super(message);
	}
}
