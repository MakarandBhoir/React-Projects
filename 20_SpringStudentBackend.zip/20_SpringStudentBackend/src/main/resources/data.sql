Insert Into Department_Tbl(Department_Id, Department_Name) Values(10, 'IT');
Insert Into Department_Tbl(Department_Id, Department_Name) Values(20, 'Electronics');
Insert Into Department_Tbl(Department_Id, Department_Name) Values(30, 'Mechanical');
