class Student {
    studentId = '';
    studentName = '';
    studentScore = '';
}
export default Student;