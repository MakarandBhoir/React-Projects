import axios from 'axios';

class StudentService {
    addStudent(student) {
        alert(JSON.stringify(student));
        return axios.post('http://localhost:9090/student-api/students/', student);
    }
    findAllStudents() {
        return axios.get('http://localhost:9090/student-api/students/');
    }
    deleteStudent(studentId) {
        return axios.delete(`http://localhost:9090/student-api/students/deleteById/${studentId}`);
    }
    findStudentById(studentId) {
        return axios.get(`http://localhost:9090/student-api/students/searchById/${studentId}`);
    }
    updateStudent(student) {
        // alert(JSON.stringify(student))
        return axios.put('http://localhost:9090/student-api/students/', student);
    }
}
export default StudentService;