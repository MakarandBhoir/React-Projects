import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import StudentService from "../service/StudentService";

function DeleteStudent() {
    const [student, setStudent] = useState({});
    let { studentId } = useParams();
    const navigate = useNavigate();
    let service = new StudentService();
    let result = '';
    // componentDidMount
    // componentDidUpdate
    useEffect(() => {
        //confirm('Are you sure?');
        service.deleteStudent(studentId).then(() => {
            //result = `Student with id = ${studentId} deleted.`
            alert(`Student with id ${studentId} is deleted.`);
            navigate('/student/home');
        }).catch((error) => {
            //result = `There is some problem deleting record.`
        })
    })
    return (
        <div className="alert alert-danger">Student with id = {studentId} deleted.</div>
    );
}
export default DeleteStudent;