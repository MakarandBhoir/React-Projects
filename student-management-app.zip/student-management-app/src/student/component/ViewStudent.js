import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router';
import { Link } from 'react-router-dom';
import Header from '../../layout/component/Header';
import StudentService from "../service/StudentService";

export default function ViewStudent() {
    const navigate = useNavigate();
    let service = new StudentService();
    const [state, setState] = useState({ students: [] });
    useEffect(() => {
        if (sessionStorage.getItem('username') != null) {
            service.findAllStudents().then((result) => {
                setState({ students: result.data });
            }).catch((error) => {
                alert(error);
            })
        } else {
            alert('Unauthorised Access to Page.');
            navigate('/student/login');
        }
    }, [])
    return (
        <div>
            <Header title="React SPA using Router"
                description="A single-page application is a web application or website that interacts with the user by dynamically rewriting the current web page with new data from the web server, instead of the default method of a web browser loading entire new pages." />
            <div>
                <div className="mt-3">
                    {
                        state.students.length > 0 ?
                            (
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Student Id</th>
                                            <th>Student Name</th>
                                            <th>Student Score</th>
                                            <th>Delete?</th>
                                            <th>Update</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            state.students.map((stu) =>
                                            ( // start
                                                <tr>
                                                    <td>{stu.studentId}</td>
                                                    <td>{stu.studentName}</td>
                                                    <td>{stu.studentScore}</td>
                                                    <td><Link className="btn btn-danger" to={{ pathname: `/student/delete/${stu.studentId}` }}>Delete</Link></td>
                                                    <td><Link className="btn btn-warning" to={{ pathname: `/student/update/${stu.studentId}` }}>Update</Link></td>
                                                </tr>
                                            ) // end
                                            ) // map closing
                                        }
                                    </tbody>
                                </table>
                            ) : <span className="alert alert-danger">No Student Present</span>
                    }
                </div>
            </div>
        </div>
    )
}
