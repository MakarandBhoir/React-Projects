import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import { Link } from "react-router-dom";
import Header from "../../layout/component/Header";
import Student from "../model/Student";
import StudentService from "../service/StudentService";

function UpdateStudent() {
    const [state, setState] = useState({ student: new Student() });
    let service = new StudentService();
    const { studentId } = useParams();
    const navigate = useNavigate();
    useEffect(() => {
        service.findStudentById(studentId).then((result) => {
            setState({ student: result.data })
        }).catch((error) => {
            alert(error);
        })
    }, []);
    return (
        <div>
            <Header title="React SPA using Router"
                description="A single-page application is a web application or website that interacts with the user by dynamically rewriting the current web page with new data from the web server, instead of the default method of a web browser loading entire new pages." />

            <form>
                <div>
                    <label>Student Id</label>
                    <input className="form-control" type="text" id="studentId" placeholder="Enter Student Id"
                        value={state.student.studentId}
                        readOnly={true}
                    />
                </div>
                <div>
                    <label>Student Name</label>
                    <input className="form-control" type="text" id="studentName" placeholder="Enter Student Name"
                        value={state.student.studentName}
                        onChange={(e) => setState({ student: { ...state.student, studentName: e.target.value } })}
                    />
                </div>
                <div>
                    <label>Student Score</label>
                    <input className="form-control" type="text" id="studentScore" placeholder="Enter Student Score"
                        value={state.student.studentScore}
                        onChange={(e) => setState({ student: { ...state.student, studentScore: e.target.value } })}
                    />
                </div>
                <button className="btn btn-outline-primary mt-3" onClick={
                    (e) => {
                        e.preventDefault();
                        service.updateStudent(state.student).then(() => {
                            alert('Student record is updated.');
                            setState({ student: {} })
                            navigate('/student/home');
                        }).catch((error) => {
                            alert(error);
                        })
                    }
                }>Update Student</button>
                <Link className="btn btn-outline-primary mt-3 ml-3" to='/student/home'>Cancel</Link>
            </form>
        </div>
    );
}
export default UpdateStudent;