import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../layout/component/Header";
import Student from "../model/Student";
import StudentService from "../service/StudentService";

function AddStudent() {
    let service = new StudentService();
    const [state, changeState] = React.useState({ student: new Student() });
    const navigate = useNavigate();
    const [error, setError] = React.useState({
        idError: '',
        nameError: '',
        scoreError: '',
    });
    useEffect(() => {
        if (sessionStorage.getItem('username') == null) {
            alert('Unauthorised Access to Page.');
            navigate('/student/login');
        }
    }, [])
    return (
        <div>
            <Header title="React SPA using Router"
                description="A single-page application is a web application or website that interacts with the user by dynamically rewriting the current web page with new data from the web server, instead of the default method of a web browser loading entire new pages." />
            <form>
                <h2><span className="badge badge-dark">Student Form</span></h2>
                <div className="form-group">
                    <div className="text-danger">{error.idError}</div>

                    <input className="form-control" type="text" id="studentId" name="studentId" placeholder="Enter Student Id"
                        value={state.student.studentId}
                        onChange={(e) => changeState({ student: { ...state.student, studentId: e.target.value } })}
                    />
                </div>
                <div className="form-group">
                    <div className="text-danger">{error.nameError}</div>

                    <input className="form-control" type="text" id="studentName" name="studentName" placeholder="Enter Student Name"
                        value={state.student.studentName}
                        onChange={(e) => changeState({ student: { ...state.student, studentName: e.target.value } })}
                    />
                </div>
                <div className="form-group">
                    <div className="text-danger">{error.scoreError}</div>

                    <input className="form-control" type="text" id="studentScore" name="studentScore" placeholder="Enter Student Score"
                        value={state.student.studentScore}
                        onChange={(e) => changeState({ student: { ...state.student, studentScore: e.target.value } })}
                    />
                </div>
                <button className="btn btn-primary" onClick={(event) => {
                    event.preventDefault();
                    let err = {};
                    let isError = false;
                    if (!state.student.studentId) {
                        err.idError = "Student Id Required.";
                        isError = true;
                    }
                    if (!state.student.studentName) {
                        err.nameError = "Student Name Required.";
                        isError = true;
                    }
                    if (!state.student.studentScore) {
                        err.scoreError = "Student Score Required.";
                        isError = true;
                    }
                    if (!isError) {
                        service.addStudent(state.student).then(() => {
                            alert("Student Added Successfully.");
                            // redirect to home page (ViewStudent)
                            navigate('/student/home');
                        }).catch(() => {
                            alert("There is some problem.");
                        });
                    } else {
                        setError(err);
                    }

                    // alert('Test'); this code will execute before line 89 or line 94
                }}>Add Student</button>
            </form>
        </div>
    )
}
export default AddStudent;