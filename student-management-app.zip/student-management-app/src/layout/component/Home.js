import React from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from "../../authentication/component/Login";
import Logout from "../../authentication/component/Logout";
import AddStudent from "../../student/component/AddStudent";
import DeleteStudent from "../../student/component/DeleteStudent";
import UpdateStudent from "../../student/component/UpdateStudent";
import ViewStudent from "../../student/component/ViewStudent";

import Header from './Header'

class Home extends React.Component {
    render() {
        return (
            <div className="container">
                <Router>
                    <Routes>
                        <Route path="/" element={<Login />} />
                        <Route path="/student/login" element={<Login />} />
                        <Route path="/student/logout" element={<Logout />} />
                        <Route path="/student/home" element={<ViewStudent />} />
                        <Route path="/student/add" element={<AddStudent />} />
                        <Route path="/student/delete/:studentId" element={<DeleteStudent />} />
                        <Route path="/student/update/:studentId" element={<UpdateStudent />} />
                    </Routes>
                </Router>
            </div>
        );
    }
}
export default Home;