import React, { useState, useEffect } from 'react';
import Post from './Post';
import axios from 'axios';
import Pagination from './Pagination';

//const url = 'data.json';
const url = 'https://jsonplaceholder.typicode.com/posts';

export default function App() {
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get('data.json').then((result) => {
      setPosts(result.data);
      //alert(JSON.stringify(result.data))
    }).catch((error) => {
      setError(error);
    });
  }, []);
  if (error) <div>{error}</div>
  return (
    <div>
      {posts.length > 0 ? (
        <>
          <Pagination
            data={posts}
            RenderComponent={Post}
            title="Posts"
            pageLimit={5}
            dataLimit={10}
          />
        </>
      ) : (
        <h1>No Posts to display</h1>
      )}
    </div>
  );
}