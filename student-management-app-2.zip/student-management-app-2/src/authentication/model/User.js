class User {
    username = '';
    password = '';
}
export default User;