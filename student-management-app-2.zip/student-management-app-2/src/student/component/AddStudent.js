import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router';
import StudentService from "../service/StudentService";
import Student from "../model/Student";
import { Link } from "react-router-dom";
import Header from "../../layout/component/Header";

function AddStudent() {
    const navigate = useNavigate();
    let service = new StudentService();
    const [unauthoriseAccess, setAccess] = useState(true);
    const [state, setState] = useState({ student: new Student() });
    const [departments, setDepartments] = useState([]);
    const [error, setError] = useState({
        idError: "",
        nameError: "",
        scoreError: "",
        deptError: "",
    })
    useEffect(() => {
        if (sessionStorage.getItem('username') != null) {
            setAccess(false);
            service.getAllDepartment()
                .then((result) => {
                    let depts = result.data.map((dept) => {
                        return { value: dept.departmentId, display: dept.departmentName };
                    });
                    setDepartments(
                        [{ value: "-1", display: "Select Department" }].concat(
                            depts
                        ),
                    );
                }).catch((error) => {
                    alert(JSON.stringify("error: " + error));
                });
        } else {
            alert('Unauthorised Access to Page.');
            navigate('/student/login');
        }
    }, [unauthoriseAccess, navigate])

    return (
        <div>
            <Header title="React SPA using Router"
                description="A single-page application is a web application or website that interacts with the user by dynamically rewriting the current web page with new data from the web server, instead of the default method of a web browser loading entire new pages." />
            {unauthoriseAccess ? (<div className="alert alert-danger">Unauthorise Access</div>) : (
                <div>
                    <form>
                        <div>
                            <div className="alert-danger">{error.idError}</div>
                            <input className="form-control" type="text" id="studentId" placeholder="Enter Student Id"
                                value={state.student.studentId}
                                onChange={(e) => {
                                    setState({
                                        student: {
                                            ...state.student,
                                            ...state.student.department,
                                            studentId: e.target.value
                                        }
                                    })
                                }}
                            />
                        </div>
                        <div>
                            <div className="alert-danger">{error.nameError}</div>
                            <input className="form-control my-2" type="text" id="studentName" placeholder="Enter Student Name"
                                value={state.student.studentName}
                                onChange={(e) => setState({
                                    student: {
                                        ...state.student,
                                        ...state.student.department,
                                        studentName: e.target.value
                                    }
                                })}
                            />
                        </div>
                        <div>
                            <div className="alert-danger">{error.scoreError}</div>
                            <input className="form-control" type="text" id="studentScore" placeholder="Enter Student Score"
                                value={state.student.studentScore}
                                onChange={(e) => setState({
                                    student:
                                    {
                                        ...state.student,
                                        ...state.student.department,
                                        studentScore: e.target.value
                                    }
                                })}
                            />
                        </div>
                        <div>
                            <div className="alert-danger">{error.deptError}</div>
                            <select
                                className="form-control my-2"
                                value={state.student.department.departmentId}
                                onChange={(event) =>
                                    setState({ student: { ...state.student, department: { ...state.student.department, departmentId: event.target.value } } })
                                }
                            >
                                {departments.map((dept) => (
                                    <option key={dept.value} value={dept.value}>
                                        {dept.display}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <button className="btn btn-outline-primary mt-3" onClick={
                            (e) => {
                                e.preventDefault();
                                let isValid = true;
                                let err = {};
                                if (!state.student.studentId) {
                                    err.idError = "Student Id Is Required";
                                    isValid = false
                                }
                                if (!state.student.studentName) {
                                    isValid = false
                                    err.nameError = "Student Name Is Required";
                                }
                                if (!state.student.studentScore) {
                                    isValid = false
                                    err.scoreError = "Student Id Score Required";
                                }
                                if (!state.student.department.departmentId) {
                                    isValid = false;
                                    err.deptError = "Student Department Required";
                                }

                                if (!isValid) {// when isValid value is false
                                    setError(err)
                                    return false;
                                }
                                service.addStudent(state.student)
                                    .then((result) => {
                                        alert('Student is added in database.');
                                        navigate('/student/home');
                                    })
                                    .catch((error) => {
                                        alert(error)
                                    });
                            }
                        }>Add Student</button>
                        <Link className="btn btn-outline-primary mt-3 ml-3" to='/home'>Cancel</Link>
                    </form>
                </div>
            )}
        </div>
    )
}
export default AddStudent;