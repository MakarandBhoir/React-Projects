import { Department } from "./Department";

class Student {
    studentId = '';
    studentName = '';
    studentScore = '';
    department = new Department();
}
export default Student;