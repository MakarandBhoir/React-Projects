export class Department {
    departmentId = "";
    departmentName = "";
}