import { Link } from "react-router-dom";

function Header(props) {
    return (
        <div className="jumbotron">
            <h1 className="display-4">{props.title}</h1>
            <p className="lead">{props.description}</p>
            <Link className="mr-1" to={`/student/home`}>Home</Link> |
            <Link className="ml-2" to={`/student/add`}>Add Student</Link> |
            {
                sessionStorage.getItem('username') != null ?
                    (<Link className="ml-2" to={`/student/logout`}>Logout</Link>) : null
            }
        </div>
    )
}
export default Header;