import React from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from "../../authentication/component/Login";
import Logout from "../../authentication/component/Logout";
import Register from "../../authentication/component/Register";
import AddMovie from "../../movies/component/AddMovie";
import DeleteMovie from "../../movies/component/DeleteMovie";
import FindAllMovies from "../../movies/component/FindAllMovies";
import FindMovie from "../../movies/component/FindMovie";

class Home extends React.Component {
    render() {
        return (
            <div className="container">
                <Router>
                    <Routes>
                        <Route path="/" element={<Login />} />
                        <Route path="/movies-app/login" element={<Login />} />
                        <Route path="/movies-app/register" element={<Register />} />
                        <Route path="/movies-app/logout" element={<Logout />} />
                        <Route path="/movies-app/home" element={<FindAllMovies />} />
                        <Route path="/movies-app/add" element={<AddMovie />} />
                        <Route path="/movies-app/delete/:movieId" element={<DeleteMovie />} />
                        <Route path="/movies-app/find/:movieId" element={<FindMovie />} />
                    </Routes>
                </Router>
            </div>
        );
    }
}
export default Home;