export class User {
    fullname = "";
    email = "";
    username = "";
    password = "";
}