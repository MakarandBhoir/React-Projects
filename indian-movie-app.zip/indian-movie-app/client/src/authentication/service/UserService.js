import axios from "axios";

class UserSerivce {
    loginService(user) {
        // alert('service---->' + JSON.stringify(user));
        return axios.post('http://localhost:5000/api/users/login', user);
    }
    register(user){
        return axios.post('http://localhost:5000/api/users/register', user);
    }
}
export default UserSerivce;