import { useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { MovieService } from "../service/MovieService";
function DeleteStudent() {
    let { movieId } = useParams();
    const navigate = useNavigate();
    let service = new MovieService();

    useEffect(() => {
        service.deleteMovie(movieId).then(() => {
            alert(`Movie with id ${movieId} is deleted.`);
            navigate('/movies-app/home');
        }).catch((error) => {
            alert(`There is some problem deleting record.`);
        })
    })
    return (
        <div className="alert alert-danger">Deleting Movie...</div>
    );
}
export default DeleteStudent;