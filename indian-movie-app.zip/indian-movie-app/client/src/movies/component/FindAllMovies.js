import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom';
import Header from '../../layout/component/Header';
import { MovieService } from '../service/MovieService';

export default function FindAllMovies() {
    let service = new MovieService();
    // const navigate = useNavigate();
    const [state, setState] = useState({ movies: [] });

    useEffect(() => {
        service.findAllMovies().then((result) => {
            setState({ movies: result.data });
        }).catch((error) => {
            alert(error)
        })
    });
    return (
        <div>
            <Header title="Indian Movie Application"
                description="This is Indian Movie Application created in React..." />
            <div>
                <div className="mt-3">
                    {
                        state.movies.length > 0 ?
                            (
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Movie Name</th>
                                            <th>Director</th>
                                            <th>Actor</th>
                                            <th>Year</th>
                                            <th>Reviewer</th>
                                            <th>Delete?</th>
                                            <th>Update</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            state.movies.map((m) =>
                                            ( // start
                                                <tr key={m._id}>
                                                    <td>{m.title}</td>
                                                    <td>{m.directors}</td>
                                                    <td>{m.actors}</td>
                                                    <td>{m.year}</td>
                                                    <td>{m.reviews.length !== 0 ? m.reviews.name : (<span>No Review</span>)}</td>
                                                    <td><Link className="btn btn-danger" to={{ pathname: `/movies-app/delete/${m._id}` }}>Delete</Link></td>
                                                    <td><Link className="btn btn-warning" to={{ pathname: `/movies-app/find/${m._id}` }}>View</Link></td>
                                                </tr>
                                            ) // end
                                            ) // map closing
                                        }
                                    </tbody>
                                </table>
                            ) : <span className="alert alert-danger">No Student Present</span>
                    }
                </div>
            </div>
        </div>
    )

}
