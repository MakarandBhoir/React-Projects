import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import Header from '../../layout/component/Header';
import { MovieService } from '../service/MovieService';

export default function FindMovie() {
    let service = new MovieService();
    // const navigate = useNavigate();
    const { movieId } = useParams();
    const [state, setState] = useState({ movie: {} });

    useEffect(() => {
        service.findMovieById(movieId).then((result) => {
            setState({ movie: result.data });
        }).catch((error) => {
            alert(error)
        })
    });
    return (
        <div>
            <Header title="Indian Movie Application"
                description="This is Indian Movie Application created in React..." />
            <div>
                <div className="mt-3">
                    <table className="table table-bordered">
                        <thead>
                            <tr>
                                <th>Movie Name</th>
                                <td>{state.movie.title}</td>
                            </tr>
                            <tr>
                                <th>Director</th>
                                <td>{state.movie.directors}</td>
                            </tr>
                            <tr>
                                <th>Actor</th>
                                <td>{state.movie.actors}</td>
                            </tr>
                            <tr>
                                <th>Year</th>
                                <td>{state.movie.year}</td>
                            </tr>
                            <tr>
                                <th>Poster</th>
                                <td><img src={state.movie.poster} height="120" width="120" /></td>
                            </tr>
                            <tr>
                                <th>Trailer</th>
                                <td>
                                    <video controls="controls" src={state.movie.trailer} height="120" width="120">
                                        Your browser does not support the HTML5 Video element.
                                    </video>
                                </td>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div >
    )

}
