
export class Review {
    name = ""; //reviewer name
    rating;
    reviewDate;
    comment;
}