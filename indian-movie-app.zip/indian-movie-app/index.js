// npm install package-name --save-dev

//importing modules
const express = require('express');
const mongoose = require('mongoose');
var cors = require('cors')

//var bodyParser = require('body-parser');
//var config = require('config');
// var http = require('http');


//Initiate express
var app = express();

//configuring express middleware
//app.use(bodyParser.json());
app.use(express.json());
// app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));
app.use(cors());


//Enabling CORS
// app.use(function (req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//     next();
// });

//user defined modules
var movieRoutes = require('./routes/movie-routes');
var userRoutes = require('./routes/user-routes');

//defining routes
app.use('/api/movies', movieRoutes);
app.use('/api/users', userRoutes);

//configuring mongodb
//const mongoServer = `mongodb://${config.get('mongodb.server')}/${config.get('mongodb.db')}`;
const mongoServer = `mongodb+srv://makarand:makarand@cluster0.abesf.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`;

mongoose.connect(mongoServer, { useNewUrlParser: true });
mongoose.connection.on("connected", function () {
    // console.log(`Connected to mongodb on ${config.get('mongodb.server')}`)
    console.log(`Connected to mongodb`)
});

// mongoose.connection.on("err", function (err) {
//     if (err)
//         // console.log(`Unable to connect to mongodb on ${config.get('mongodb.server')}`);
//         console.log(`Unable to connect to mongodb`);
// });

//creating and starting web server
app.listen(5000, () => {
    console.log('Listing on port 5000.');
})