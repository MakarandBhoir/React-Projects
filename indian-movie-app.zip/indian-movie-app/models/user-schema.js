
const mongoose = require('mongoose');
var bcrypt = require('bcrypt');

var Schema = mongoose.Schema;

var UserSchema = new Schema({
    fullname: { type: String, required: true },
    email: { type: String, required: true, unique: true, trim: true },
    username: { type: String, required: true, unique: true, trim: true },
    password: { type: String, required: true },
});

//Hash the password before saving
UserSchema.pre('save', function (next) {
    var user = this;
    bcrypt.hash(user.password, 10, function (err, hash) {
        if (err) {
            return next(err);
        }
        user.password = hash;
        next();
    })
});

UserSchema.statics.authenticate = function (username, password, callback) {
    let user = this;
    user.findOne({ username: username })
        .exec(function (err, user) {
            if (err) {
                return callback(err)
            }
            else if (!user) {
                var err = new Error('User not found.');
                err.status = 401;
                return callback(err);
            }
            bcrypt.compare(password, user.password, function (err, result) {
                if (result === true) {
                    return callback(null, user);
                } else {
                    var err = new Error('Invalid username/password.');
                    err.status = 401;
                    return callback(err, null);
                }
            })
        });
}
module.exports = mongoose.model('User', UserSchema);