module.exports = {
    DB_URL: `mongodb+srv://makarand:makarand@cluster0.abesf.mongodb.net/JWTDatabase?retryWrites=true&w=majority`
};