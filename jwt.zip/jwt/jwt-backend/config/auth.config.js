module.exports = {
    secret: 'do-not-tell-anybody'
};