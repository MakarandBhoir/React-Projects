const { authJwt } = require("../middlewares");
const controller = require("../controllers/user.controller");
const express = require("express");
var router = express.Router();
// http://localhost:5050/api/users/all
router.get("/all", controller.allAccess);

//http://localhost:5050/api/users/user
router.get("/user", [authJwt.verifyToken], controller.userBoard);

router.get(
    "/mod",
    [authJwt.verifyToken, authJwt.isModerator],
    controller.moderatorBoard
);
// http://localhost:5050/api/users/admin
router.get(
    "/admin",
    [authJwt.verifyToken, authJwt.isAdmin],
    controller.adminBoard
);
module.exports = router;
