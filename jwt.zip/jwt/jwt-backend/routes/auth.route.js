const { verifySignUp } = require("../middlewares");
const controller = require("../controllers/auth.controller");
const express = require("express");
var router = express.Router();

// http://localhost:5050/api/auth/signup
router.post(
    "/signup",
    [
        verifySignUp.checkDuplicateUsernameOrEmail,
        verifySignUp.checkRolesExisted
    ],
    controller.signup
);

// http://localhost:5050/api/auth/signin
router.post("/signin", controller.signin);

module.exports = router;