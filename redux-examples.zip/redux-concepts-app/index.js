console.log('------- Welcome to Redux --------');

//State
let initialState = {
    "quantity": 100
}
//Action
function buyMobile() {
    return {
        "type": "BUY_MOBILE"
    }
}
// Reducer (preState, action) => newState
function reducer(state = initialState, action) {
    if (action.type == 'BUY_MOBILE') {
        state.quantity -= 1;
    }
    return state;
}
//just like we are importing redux package
const redux = require('redux');
const store = redux.createStore(reducer);

// this will call when your state modified from store
store.subscribe(() => {
    console.log('State changed: ' + JSON.stringify(store.getState()));
})

// this function call will call the reducer and reducer function will take place your state transfer.
store.dispatch(buyMobile());
store.dispatch(buyMobile());
store.dispatch({ "type": "BUY_MOBILE" });