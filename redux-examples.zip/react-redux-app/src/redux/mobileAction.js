function mobileAction() {
    return {
        "type": "BUY_MOBILE"
    }
}
export default mobileAction;