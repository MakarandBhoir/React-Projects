import { createStore } from 'redux';
import mobileReducer from './mobileReducer';
let store = createStore(mobileReducer);
export default store;