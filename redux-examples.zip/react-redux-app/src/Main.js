import React from 'react';
import { connect } from 'react-redux';
import mobileAction from './redux/mobileAction';

const Main = (props) => {
    return (<div>
        <div className='alert alert-success'>
            Qantity: {props.quantity} - <button className='btn btn-danger' onClick={props.buyMobile}>Buy Mobile</button>
        </div>
    </div>);
};

const mapStateToProps = (state) => ({
    quantity: state.quantity
});

const mapDispatchToProps = (dispatch) => {
    return {
        buyMobile: () => dispatch(mobileAction())
    }
}

// connect is responsible for connecting store to the component
export default connect(mapStateToProps, mapDispatchToProps)(Main);
