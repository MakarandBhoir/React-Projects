import Header from "./Header";
import Main from "./Main";

function App() {
  return (
    <div className="container">
      <Header title="React-Redux Project"
        description="This project will include redux concepts to manage the state of the application."
      />
      <Main />
    </div>
  );
}

export default App;
