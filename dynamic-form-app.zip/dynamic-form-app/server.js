const express = require('express');
const mongoose = require('mongoose')
const cors = require('cors')
const EmployeeSchema = require('./model/employee-schema');
const UserTypeSchema = require('./model/usertype.schema');
const RoleSchema = require('./model/role.schema');
const Role = require('./model/role.schema');
const UserType = require('./model/usertype.schema');
const { ObjectId } = require('bson');

const app = express();
app.use(express.json());
app.use(express.static(__dirname));
app.use(cors());

const mongoServer = `mongodb+srv://makarand:makarand@cluster0.abesf.mongodb.net/employeeDatabase?retryWrites=true&w=majority`;
mongoose
    .connect(`${mongoServer}`)
    .then(() => {
        console.log("Successfully connect to MongoDB.");
        setup();
    })
    .catch(err => {
        console.error("Connection error", err);
        process.exit();
    });

// set port, listen for requests
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}.`);
});

// GET http://localhost:5000/api/employees
app.get('/api/employees', (req, res) => {
    EmployeeSchema.find((err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Unable to retrieve employee data', error: err })
        }
        else {
            res.status(200).json(result);
        }
    });
});


// GET http://localhost:5000/api/usertypes
app.get('/api/usertypes', (req, res) => {
    UserTypeSchema.find((err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Unable to retrieve usertypes data', error: err })
        }
        else {
            res.status(200).json(result);
        }
    });
});
// GET http://localhost:5000/api/usertypes
app.get('/api/usertypes/:id', (req, res) => {
    UserTypeSchema.findById({ _id: req.params.id }, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Unable to retrieve usertypes data', error: err })
        }
        else {
            res.status(200).json(result);
        }
    });
});
// GET http://localhost:5000/api/usertypes/roles/id
app.get('/api/usertypes/roles/:id', (req, res) => {
    UserTypeSchema.find({ role: req.params.id }, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Unable to retrieve usertypes data', error: err })
        }
        else {
            res.status(200).json(result);
        }
    });
});


// GET http://localhost:5000/api/roles
app.get('/api/roles', (req, res) => {
    RoleSchema.find((err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Unable to retrieve roles data', error: err })
        }
        else {
            res.status(200).json(result);
        }
    });
});

// GET http://localhost:5000/api/roles/id
app.get('/api/roles/:id', (req, res) => {
    RoleSchema.findById({ _id: req.params.id }, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Unable to retrieve roles data', error: err })
        }
        else {
            res.status(200).json(result);
        }
    });
});

//Add a new employee
//POST http://localhost:5000/api/employees
// app.post('/', (req, res) => {
//     let employee = new EmployeeSchema(req.body);
//     employee.save((err, result) => {
//         if (err) {
//             res.status(500).json({ message: "Error in adding employee details", error: err });
//         }
//         else {
//             res.status(200).json({ message: 'Employee details added successfully', employee: result, location: `/api/employees/${result._id}` });
//         }
//     });
// });


function setup() {
    // Role.estimatedDocumentCount((err, count) => {
    //     if (!err && count === 0) {
    //         new Role({ level: "Director" }).save(err => {
    //             if (err) {
    //                 console.log("error", err);
    //             }
    //             console.log("added 'Director' to roles collection");
    //         });
    //         new Role({ level: "Management" }).save(err => {
    //             if (err) {
    //                 console.log("error", err);
    //             }
    //             console.log("added 'Management' to roles collection");
    //         });
    //         new Role({ level: "Executive" }).save(err => {
    //             if (err) {
    //                 console.log("error", err);
    //             }
    //             console.log("added 'Executive' to roles collection");
    //         });
    //         new Role({ level: "External" }).save(err => {
    //             if (err) {
    //                 console.log("error", err);
    //             }
    //             console.log("added 'External' to roles collection");
    //         });
    //     }
    // });

    UserType.estimatedDocumentCount((err, count) => {
        if (!err && count === 0) {
            new UserType({ usertype: "CEO", role: ObjectId("6260e9e274ca51480c21978c") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'CEO' to usertypes collection");
            });

            new UserType({ usertype: "CFO", role: ObjectId("6260e9e274ca51480c21978c") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'CFO' to usertypes collection");
            });

            new UserType({ usertype: "Project Manager", role: ObjectId("625fc13fc43d3fc3b05e7a29") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Project Manager' to usertypes collection");
            });
            new UserType({ usertype: "Scrum Master", role: ObjectId("6260e9e274ca51480c21978d") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Scrum Master' to usertypes collection");
            });
            new UserType({ usertype: "Team Leader", role: ObjectId("6260e9e274ca51480c21978d") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Team Leader' to usertypes collection");
            });
            new UserType({ usertype: "Resource Manager", role: ObjectId("6260e9e274ca51480c21978d") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Resource Manager' to usertypes collection");
            });
            new UserType({ usertype: "Team Member", role: ObjectId("6260e9e274ca51480c21978e") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Team Member' to usertypes collection");
            });
            new UserType({ usertype: "Help Desk Operator", role: ObjectId("6260e9e274ca51480c21978e") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Help Desk Operator' to usertypes collection");
            });
            new UserType({ usertype: "Client", role: ObjectId("6260e9e274ca51480c21978f") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'Client' to usertypes collection");
            });
            new UserType({ usertype: "External Worker", role: ObjectId("6260e9e274ca51480c21978f") }).save(err => {
                if (err) {
                    console.log("error", err);
                }
                console.log("added 'External Worker' to usertypes collection");
            });
        }
    });
}