import axios from 'axios';

class EmployeeService {
    getAllRoles() {
        return axios.get('http://localhost:5000/api/roles/');
    }
    getAllUserTypesByRole(role) {
        return axios.get(`http://localhost:5000/api/usertypes/roles/${role}`);
    }
}
export default EmployeeService;
