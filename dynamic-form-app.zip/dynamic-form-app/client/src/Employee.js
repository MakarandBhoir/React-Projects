import React, { useEffect, useState } from 'react'
import EmployeeService from './EmployeeService';

export default function Employee() {
    const [selectedRole, setSelectedRole] = useState();
    const [selectedUserType, setSelectedUserType] = useState();

    const [roles, setRoles] = useState([]);
    const [userTypes, setUserTypes] = useState([]);
    let service = new EmployeeService();
    useEffect(() => {
        service.getAllRoles()
            .then((result) => {
                let r = result.data.map((role) => {
                    return { value: role._id, display: role.level };
                });
                setRoles(
                    [{ value: "-1", display: "Select Role" }].concat(
                        r
                    ),
                );
            }).catch((error) => {
                console.log(JSON.stringify("error: " + error));
            });

    }, [])

    return (
        <div>
            <div>
                <form>
                    <div>
                        <select
                            className="form-control my-2"
                            value={selectedRole}
                            onChange={(event) => {
                                setSelectedRole(event.target.value)
                                service.getAllUserTypesByRole(event.target.value).then((result) => {
                                    alert(JSON.stringify(result.data))
                                    let ut = result.data.map((type) => {
                                        return { value: type._id, display: type.usertype };
                                    });
                                    setUserTypes(
                                        [{ value: "-1", display: "Select UserTypes" }].concat(
                                            ut
                                        ),
                                    );

                                }).catch((error) => {
                                    console.log(JSON.stringify("error: " + error));
                                })
                            }
                            }
                        >
                            {roles.map((role) => (
                                <option key={role.value} value={role.value}>
                                    {role.display}
                                </option>
                            ))}
                        </select>

                        <select
                            className="form-control my-2"
                            value={selectedUserType}
                            onChange={(e) => {
                                setSelectedUserType(e.target.value)
                            }}
                        >
                            {userTypes.map((ut) => (
                                <option key={ut.value} value={ut.value}>
                                    {ut.display}
                                </option>
                            ))}
                        </select>
                    </div>
                    <button className="btn btn-outline-primary mt-3" onClick={(e) => {
                        e.preventDefault();
                        alert(selectedRole + ":" + selectedUserType)
                    }}>Add Employee</button>
                </form>
            </div >
        </div >
    )
}