import logo from './logo.svg';
import './App.css';
import Employee from './Employee';

function App() {
  return (
    <div className="App">
      <Employee />

    </div>
  );
}

export default App;
