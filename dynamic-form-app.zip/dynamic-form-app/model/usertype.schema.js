const mongoose = require("mongoose");
const Role = require("./role.schema");

let UserTypeSchema = new mongoose.Schema({
    usertype: { type: String, required: true, unique: true },
    role: {
        type: mongoose.Schema.Types.ObjectId,
        ref: Role
    }
})
let UserType = mongoose.model("UserType", UserTypeSchema);
module.exports = UserType;