const mongoose = require("mongoose");

let RoleSchema = new mongoose.Schema({
    level: { type: String, required: true, unique: true },
});
let Role = mongoose.model("Role", RoleSchema);
module.exports = Role;
