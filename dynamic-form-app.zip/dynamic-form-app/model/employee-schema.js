const mongoose = require("mongoose");

let EmployeeSchema = new mongoose.Schema({
    employeeId: { type: String, required: true, unique: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    // role:,
    // usertype: 
});
let Employee = mongoose.model("Employee", EmployeeSchema);
module.exports = Employee;