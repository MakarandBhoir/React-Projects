import { useState } from 'react';
import './App.css';

function App() {
  const [inputFields, setInputFields] = useState([
    { studentId: '', studentName: '', studentScore: '' }
  ])
  const handleFormChange = (index, event) => {
    let data = [...inputFields];
    data[index][event.target.name] = event.target.value;
    setInputFields(data);
  }
  const addFields = (e) => {
    e.preventDefault();
    // e.preventDefaults();
    let newfield = { studentId: '', studentName: '', studentScore: '' }

    setInputFields([...inputFields, newfield])
  }
  const submit = (e) => {
    e.preventDefault();
    console.log(inputFields)
  }
  const removeFields = (index) => {
    let data = [...inputFields];
    data.splice(index, 1)
    setInputFields(data)
  }
  return (
    <div className="App">
      <form onSubmit={submit}>
        <table>
          <thead>
            <tr>
              <th>Student Id</th>
              <th>Student Name</th>
              <th>Student Score</th>
            </tr>
          </thead>
          <tbody>
            {inputFields.map((input, index) => {
              return (
                <tr key={index}>
                  <td>
                    <input
                      className='mr-3'
                      name='studentId'
                      placeholder='Student Id'
                      value={input.studentId}
                      onChange={event => handleFormChange(index, event)}
                    />
                  </td>
                  <td>
                    <input
                      className='mr-3'
                      name='studentName'
                      placeholder='Student Name'
                      value={input.studentName}
                      onChange={event => handleFormChange(index, event)}
                    />
                  </td>
                  <td>
                    <input
                      className='mr-3'
                      name='studentScore'
                      placeholder='Student Score'
                      value={input.studentScore}
                      onChange={event => handleFormChange(index, event)}
                    />
                  </td>
                  <td>
                    <button className='btn btn-danger' onClick={() => removeFields(index)}>-</button>
                  </td>
                </tr>
              )
            })}
            <tr>
              <td>
                <button className='btn btn-primary' onClick={addFields}>Add Row</button>
                <button className='btn btn-primary mx-3' onClick={submit} disabled={inputFields.length == 0 ? true : false}>Submit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
}

export default App;