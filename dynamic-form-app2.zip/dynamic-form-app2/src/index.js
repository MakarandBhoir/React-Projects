import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <div className='container'>
      <div className="jumbotron">
        <h1 className="display-4">React Dynamic Form Example!</h1>
        <p className="lead">Dynamic form creation example</p>
      </div>
      <App />
    </div>
  </React.StrictMode>
);
