
const mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ReviewSchema = new Schema({
    name: { type: String, required: true },
    rating: { type: Number, required: false, min: 1, max: 5 },
    reviewDate: { type: Date, required: false },
    comment: { type: String }
});


var MovieSchema = new Schema({
    title: { type: String, required: true, unique: true },
    actors: { type: String, required: true },
    directors: { type: String, required: true },
    year: { type: String, required: true },
    poster: { type: String, required: false },
    trailer: { type: String, required: false },
    reviews: [ReviewSchema]
});

module.exports = mongoose.model('Movie', MovieSchema);