import { useEffect } from "react"
import { useNavigate } from "react-router";

function Logout() {
    const navigate = useNavigate();
    useEffect(() => {
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('user');
        navigate('/movies-app/login');
    })
    return (
        <div>Logging Out</div>
    )
}
export default Logout;