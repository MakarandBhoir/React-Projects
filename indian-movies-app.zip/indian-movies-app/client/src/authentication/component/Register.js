import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../layout/component/Header";
import { User } from "../model/user";
import UserSerivce from "../service/UserService";

function Register() {
    let service = new UserSerivce();
    const [state, changeState] = React.useState({ user: new User() });
    const navigate = useNavigate();
    // useEffect(() => {
    //     if (sessionStorage.getItem('username') == null) {
    //         alert('Unauthorised Access to Page.');
    //         navigate('/movies-app/login');
    //     }
    // })
    return (
        <div>
            <Header title="Indian Movie Application"
                description="This is Indian Movie Application created in React..." />
            <form>
                <h2><span className="badge badge-dark">User Registration Form</span></h2>
                <div className="form-group">
                    <input className="form-control" type="text" id="fullname" name="fullname" placeholder="Enter Fullname"
                        value={state.user.fullname}
                        onChange={(e) => changeState({ user: { ...state.user, fullname: e.target.value } })}
                    />
                </div>
                <div className="form-group">
                    <input className="form-control" type="text" id="email" name="email" placeholder="Enter Email"
                        value={state.user.email}
                        onChange={(e) => changeState({ user: { ...state.user, email: e.target.value } })}
                    />
                </div>
                <div className="form-group">
                    <input className="form-control" type="text" id="username" name="username" placeholder="Enter Username"
                        value={state.user.username}
                        onChange={(e) => changeState({ user: { ...state.user, username: e.target.value } })}
                    />
                </div>
                <div className="form-group">
                    <input className="form-control" type="password" id="password" name="password" placeholder="Enter Password"
                        value={state.user.password}
                        onChange={(e) => changeState({ user: { ...state.user, password: e.target.value } })}
                    />
                </div>

                <button className="btn btn-primary" onClick={(event) => {
                    event.preventDefault();
                    service.register(state.user).then(() => {
                        alert("User Registration Successfully.");
                        // redirect to home page (ViewStudent)
                        navigate('/movies-app/login');
                    }).catch(() => {
                        alert("There is some problem.");
                    });
                }}>Register</button>
            </form>
        </div>
    )
}
export default Register;