import { useState } from "react";
import { useNavigate } from "react-router";
import Header from "../../layout/component/Header";
import { User } from "../model/user";
import UserSerivce from "../service/UserService";

function Login() {
    const [user, setUser] = useState({ login: new User() });
    const navigate = useNavigate();
    let service = new UserSerivce();
    return (
        <div>
            <Header title="Indian Movie Application"
                description="This is Indian Movie Application created in React..." />

            <h1>Login Page</h1>
            <form>
                <div className="form-group">
                    <label>Username</label>
                    <input className="form-control" type="text" id="username" placeholder="Enter User Name"
                        value={user.login.username}
                        onChange={(e) => setUser({ login: { ...user.login, username: e.target.value } })}
                    />
                </div>
                <div className="form-group">
                    <label>Password</label>
                    <input className="form-control" type="password" id="password" placeholder="Enter Password"
                        value={user.login.password}
                        onChange={(e) => setUser({ login: { ...user.login, password: e.target.value } })}
                    />
                </div>
                <div>
                    <button className="btn btn-outline-primary" onClick={
                        (e) => {
                            e.preventDefault();
                            service.loginService(user.login).then((result) => {
                                sessionStorage.setItem('username', user.login.username);
                                let user2 = result.data.user;
                                delete user2.password;
                                sessionStorage.setItem('user', JSON.stringify(user2));
                                console.log(user2)
                                navigate('/movies-app/home');
                            }).catch((error) => {
                                alert('Invalid Username/Password. Please try again!');
                            })
                        }
                    }>Login</button>
                </div>
            </form>
        </div>
    );
}
export default Login;