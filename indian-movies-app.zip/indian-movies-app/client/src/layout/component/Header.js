import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Header(props) {
    const [user, setUser] = useState();
    useEffect(() => {
        if (sessionStorage.getItem('user')) {
            setUser(JSON.parse(sessionStorage.getItem('user')));
        }
    }, [])
    return (
        <div className="jumbotron">
            <h1 className="display-4">{props.title}</h1>
            <p className="lead">{props.description}</p>
            <Link className="mr-1" to={`/movies-app/add`}>Add Movie</Link> |
            {
                sessionStorage.getItem('username') == null ?
                    <span className="ml-2"><Link className="mr-1" to={`/movies-app/register`}>Register</Link></span> : null
            }
            {
                sessionStorage.getItem('username') != null ?
                    (
                        <span>
                            <Link className="ml-2" to={`/movies-app/logout`}>Logout</Link>
                            {user ?
                                <p className="text-success">Welcome {user.fullname}</p>
                                :
                                null
                            }
                        </span>
                    ) : null
            }

        </div>
    )
}
export default Header;