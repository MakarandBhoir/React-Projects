import Home from "./layout/component/Home";

function App() {
  return (
    <Home />
  );
}

export default App;
