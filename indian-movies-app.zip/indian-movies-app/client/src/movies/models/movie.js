export class Movie {
    title = "";
    actors = "";
    directors = "";
    year = 0;
    poster = "";
    trailer = "";
    reviews = [];
}