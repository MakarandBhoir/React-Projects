import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../layout/component/Header";
import { Movie } from '../models/movie'
import { MovieService } from "../service/MovieService";
function AddMovie() {
    let service = new MovieService();
    const [state, changeState] = React.useState({ movie: new Movie() });
    const navigate = useNavigate();
    useEffect(() => {
        if (sessionStorage.getItem('username') == null) {
            alert('Unauthorised Access to Page.');
            navigate('/movies-app/login');
        }
    })
    return (
        <div>
            <Header title="Indian Movie Application"
                description="This is Indian Movie Application created in React..." />
            <form enctype="multipart/form-data">
                <h2><span className="badge badge-dark">Add Movie Form</span></h2>
                <div className="form-group">
                    <input className="form-control" type="text" id="title" name="title" placeholder="Enter Movie Title"
                        value={state.movie.title}
                        onChange={(e) => changeState({ movie: { ...state.movie, title: e.target.value } })}
                    />
                </div>

                <div className="form-group">
                    <input className="form-control" type="text" id="actors" name="actors" placeholder="Enter Lead Actor Name"
                        value={state.movie.actors}
                        onChange={(e) => changeState({ movie: { ...state.movie, actors: e.target.value } })}
                    />
                </div>

                <div className="form-group">
                    <input className="form-control" type="text" id="directors" name="directors" placeholder="Enter directors Name"
                        value={state.movie.directors}
                        onChange={(e) => changeState({ movie: { ...state.movie, directors: e.target.value } })}
                    />
                </div>

                <div className="form-group">
                    <input className="form-control" type="file" id="poster" name="poster" placeholder="Select Poster"
                        value={state.movie.poster}
                        onChange={(e) => changeState({ movie: { ...state.movie, poster: e.target.value } })}
                    />
                </div>

                <div className="form-group">
                    <input className="form-control" type="file" id="trailer" name="trailer" placeholder="Select trailer"
                        value={state.movie.trailer}
                        onChange={(e) => changeState({ movie: { ...state.movie, trailer: e.target.value } })}
                    />
                </div>

                <button className="btn btn-primary" onClick={(event) => {
                    event.preventDefault();
                    service.addMovie(state.movie).then(() => {
                        alert("Movie Added Successfully.");
                        // redirect to home page (ViewStudent)
                        navigate('/movies-app/home');
                    }).catch(() => {
                        alert("There is some problem.");
                    });
                }}>Add Movie</button>
            </form>
        </div>
    )
}
export default AddMovie;