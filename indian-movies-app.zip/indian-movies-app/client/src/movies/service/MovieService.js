import axios from 'axios';
export class MovieService {
    baseUrl = `http://localhost:5000`;
    findAllMovies() {
        return axios.get(`${this.baseUrl}/api/movies`);
    }
    deleteMovie(movieId) {
        return axios.delete(`${this.baseUrl}/api/movies/${movieId}`);
    }
    addMovie(movie){
        alert(JSON.stringify(movie));
        return axios.post(`${this.baseUrl}/api/movies`, movie);
    }
}