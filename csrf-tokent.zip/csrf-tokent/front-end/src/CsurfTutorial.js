import React, { useEffect, useState } from 'react'
import axios from 'axios'

axios.defaults.xsrfHeaderName = "xsrf-token";
axios.defaults.xsrfCookieName = "csrftoken";

export default function CsurfTutorial() {
    const domainUrl = 'http://localhost:5000';
    const [csrfTokenState, setCsrfTokenState] = useState('');
    const [haveWeReceivedPostResponseState, setHaveWeReceivedPostResponseState] = useState("not yet")

    function getCallToForm() {
        const url = '/form';
        axios.get(`${domainUrl}${url}`, {
            method: 'GET',
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
            },
            credentials: "include",
            mode: 'cors'
        }).then((result) => {
            let parsedResponse = result.data.csrfToken;
            console.log('before-->', csrfTokenState)
            setCsrfTokenState(parsedResponse)
            console.log('after-->', csrfTokenState)
        })
    }

    useEffect(() => {
        getCallToForm();
    }, [])

    function testCsurfPostClick() {
        const url = '/process';
        alert(csrfTokenState)
        axios.post(`${domainUrl}${url}`, {
            method: 'POST',
            data: {},
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                "csrf-token": csrfTokenState,
            },
            credentials: "include",
            mode: "cors"
        }).then((result) => {
            // alert('---->' + result.data.message)
            setHaveWeReceivedPostResponseState(result.data.message)
        })
    }

    return (
        <div>
            <input type="hidden" name="_csrf" value=""></input>
            <button onClick={testCsurfPostClick}>Test Post Call to Server</button>
            <div>csrf Token is: {csrfTokenState}</div>
            <p>Have we successfully navigated though post request?: {haveWeReceivedPostResponseState}</p>
        </div>
    )
}
