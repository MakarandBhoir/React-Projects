# CSURF-Back-End-Tutorial
Simple NodeJS server to demonstrate CSURF Working. To install:

```
git init
git remote add origin https://github.com/jimmythecode/CSURF-Back-End-Tutorial.git 
npm i
npm run start
```

See YouTube tutorials:
https://youtu.be/QruvuwM-kkU


